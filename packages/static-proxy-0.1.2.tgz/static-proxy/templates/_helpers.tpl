{{/*
Expand the name of the chart.
*/}}
{{- define "static-proxy.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "static-proxy.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "static-proxy.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "static-proxy.labels" -}}
helm.sh/chart: {{ include "static-proxy.chart" . }}
{{ include "static-proxy.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "static-proxy.selectorLabels" -}}
app.kubernetes.io/name: {{ include "static-proxy.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/* HTTPRoute name for static-proxy (single host, single resource) */}}
{{- define "static-proxy.httprouteName" -}}
{{- $root := .root -}}
{{ include "static-proxy.fullname" $root }}-httproute
{{- end }}

{{/* Map pathType to gateway.networking.k8s.io path match type */}}
{{- define "static-proxy.httproutePathMatchType" -}}
{{- $t := . | default "ImplementationSpecific" -}}
{{- if or (eq $t "Prefix") (eq $t "ImplementationSpecific") -}}
PathPrefix
{{- else if eq $t "Exact" -}}
Exact
{{- else if eq $t "RegularExpression" -}}
RegularExpression
{{- else -}}
PathPrefix
{{- end -}}
{{- end }}
